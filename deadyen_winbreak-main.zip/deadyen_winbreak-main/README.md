# deadyen_winbreak
Introducing deadyen_winbreak – your solution to the frustrating window-breaking issue. This standalone, open-source script requires players to manually roll down windows before shooting from vehicles. No more glass breaking! Enhance immersion in your FiveM server. 

# Check out our other resources [here](https://deadyen.tebex.io/category/2464850)!
# Contact us [here](https://discord.com/invite/DSEW5xWKT8)!
